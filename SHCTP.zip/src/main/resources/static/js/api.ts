function ajax(action,method,data,call) {
    var ajax=new XMLHttpRequest()
    ajax.withCredentials=true
    console.log(data)
    ajax.onreadystatechange=()=>{
        if (ajax.readyState==4) {
            if (ajax.status==200) {
                var response=JSON.parse(ajax.response)
                alert(response.information)
                if(response.code==100){
                    if(call!=null)call(response.data)
                    location.reload()
                }
            }
            else {
                alert("请求发生错误");
            }
        }
    }
    ajax.open(method,action,true)
    ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded")
    ajax.send(data)
}
function formDataAjax(action,method,data,call) {
    var ajax=new XMLHttpRequest()
    ajax.withCredentials=true
    console.log(data)
    ajax.onreadystatechange=()=>{
        if (ajax.readyState==4) {
            if (ajax.status==200) {
                var response=JSON.parse(ajax.response)
                alert(response.information)
                if(response.code==100){
                    if(call!=null)call(response.data)
                    location.reload()
                }
            }
            else {
                alert("请求发生错误");
            }
        }
    }
    ajax.open(method,action,true)
    ajax.send(data)
}
function regCall(data) {
    alert("注册成功,您的Uid为:"+data)
}
function getParam(form) {
    var params=form.getElementsByClassName('param')
    for(var i=0;i<params.length;i++)if(params[i].value==null||params[i].value==undefined||params[i].value==''){
        alert(params[i].getAttribute("name")+"不能为空")
        return null
    }
    var param=""
    for(var i=0;i<params.length;i++){
        param+=params[i].getAttribute("name")+"="+params[i].value+"&"
    }
    return param
}

function _login(form) {
    var param=getParam(form)
    if(param!=null) ajax("/Api/User/Login","POST",param,null)
    reloadVerify(form,1)
}
function _reg(form) {
    var param=getParam(form)
    if(param!=null) ajax("/Api/User/Register","POST",param,regCall)
    reloadVerify(form,0)
}
function _loginOut() {
    ajax("/Api/User/LoginOut","GET",null,null)
}

function _createOrder(form) {
    var param=getParam(form)
    if(param!=null) ajax("/Api/Order/Create","POST",param,null)
}
function _payOrder(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Order/Pay","POST",param,null);
}
function _deliverOrder(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Order/Deliver","POST",param,null);
}
function _receiveOrder(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Order/Receive","POST",param,null);
}
function _cancelOrder(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Order/Cancel","POST",param,null);
}
function _addCommodity(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Commodity/Add","POST",param,null);
}
function _updateCommodity(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Commodity/Update","POST",param,null);
}
function _removeCommodity(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Commodity/Remove","POST",param,null);
}
function _uploadExhibition(form) {
    var data=new FormData(form)
    formDataAjax("/Api/Commodity/Exhibition/Upload","POST",data,null);
}
function _removeExhibition(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Commodity/Exhibition/Remove","POST",param,null);
}
function _commitCommodity(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Commodity/Commit","POST",param,null);
}
function _uploadAvatar(form) {
    var data=new FormData(form)
    formDataAjax("/Api/User/Avatar/Upload","POST",data,null);
}
function _updateNickname(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/User/Nickname/Update","POST",param,null);
}
function _addDeliverAddr(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/User/DeliverAddress/Add","POST",param,null);
}
function _updateDeliverAddr(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/User/DeliverAddress/Update","POST",param,null);
}
function _removeDeliverAddr(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/User/DeliverAddress/Remove","POST",param,null);
}
function _endBidding(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Order/EndBidding","POST",param,null);
}
function _updatePrince(form) {
    var param=getParam(form)
    if(param!=null)ajax("/Api/Order/UpdatePrince","POST",param,null);
}
function reloadVerify(compent,type) {
    var img=compent.getElementsByTagName('img')[0]
    var session=compent.getElementsByClassName('session')[0]
    var ajax=new XMLHttpRequest()
    ajax.open("GET","/Api/RefreshVerify?type="+type+"&session="+session.value)
    ajax.send()
    ajax.onreadystatechange=function () {
        if (ajax.readyState==4) {
            if (ajax.status==200) {
                var response=JSON.parse(ajax.response)
                if(response.code==100){
                    console.log(response.data)
                    img.src=response.data.image
                    session.value=response.data.session
                }
            }
            else {
                alert("刷新验证码时发生错误");
            }
        }
    }
}