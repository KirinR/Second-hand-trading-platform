function toggleTable(tableId,val){
    var table=document.getElementById(tableId);
    var navItems=table.getElementsByClassName("nav-item")
    var tables=table.getElementsByClassName("list")
    for(var i=0;i<tables.length;i++){
        if(tables[i].getAttribute("val")==String(val)){
            if(tables[i].classList.contains('none'))tables[i].classList.remove('none')
        }else{
            if(!tables[i].classList.contains('none'))tables[i].classList.add('none')
        }
    }
    for(var i=0;i<navItems.length;i++){
        if(navItems[i].getAttribute("val")==String(val)){
            if(!navItems[i].classList.contains('nav-item-selected'))navItems[i].classList.add('nav-item-selected')
        }else{
            if(navItems[i].classList.contains('nav-item-selected'))navItems[i].classList.remove('nav-item-selected')
        }
    }
}
function closeCompent(compent,cover){
    cover.style.display='none'
    compent.style.display='none'
}
function showCompent(compent,cover){
    compent.style.display='block'
    cover.style.display='block'
    cover.style.height=document.body.clientHeight-1+'px'
    compent.style.left=(document.body.clientWidth-compent.clientWidth)/2+'px'
    compent.style.top=(document.body.clientHeight-compent.clientHeight)/2+'px'
}