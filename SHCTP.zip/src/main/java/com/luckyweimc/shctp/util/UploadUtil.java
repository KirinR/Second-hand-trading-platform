package com.luckyweimc.shctp.util;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;

/**
 * 文件上传工具类
 */
public class UploadUtil {

    /**
     * 上传文件到指定路径
     * @param file 要上传的文件
     * @param save 保存的路径
     * @return
     */
    public static String upload(MultipartFile file,String save,String returnPath){
        String fileName=file.getOriginalFilename();
        try {
            save=URLDecoder.decode(save,"utf-8");
            fileName=URLDecoder.decode(fileName,"utf-8");
            File dest = new File(save+fileName);
            if(!dest.exists())dest.createNewFile();
            file.transferTo(dest);
            return returnPath+fileName;
        }catch (IOException e){
            e.printStackTrace();
            return null;
        }
    }

}
