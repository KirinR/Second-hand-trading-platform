package com.luckyweimc.shctp.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;

/**
 * 图片工具类
 */
public class ImageUtil {
    /**
     * 根据文字生成图片
     * @param fontSize 字体大小
     * @param filename 文件名称
     * @param returnName 要返回的文件名称
     * @param text 文字
     * @return 图片路径
     * @throws IOException
     */
    public static String genImageByText(Integer fontSize,String filename,String returnName,String text) throws IOException {
        //urlencode编码转换 防止因中文路径产生的编码问题
        filename=URLDecoder.decode(filename,"utf-8");
        System.out.println(filename);
        //图片宽度为字体大小*文字长度
        int width=fontSize*text.length();
        //创建一个宽为width高为40的BufferImage
        BufferedImage image=new BufferedImage(width,40,BufferedImage.TYPE_INT_BGR);
        //创建g2d对象
        Graphics2D g2=image.createGraphics();
        //创建字体对象
        Font font=new Font("宋体", Font.BOLD, fontSize);
        //配置设置g2d画布
        g2.setClip(0,0,width,40);
        //填充背景为白色
        g2.setColor(Color.WHITE);
        g2.fillRect(0,0,width,40);
        //设置字体和文字颜色
        g2.setColor(Color.BLACK);
        g2.setFont(font);
        //设置文字位置为居中
        Rectangle clip=g2.getClipBounds();
        FontMetrics fm=g2.getFontMetrics(font);
        int ascent=fm.getAscent();
        int descent=fm.getDescent();
        int x=(clip.width-fm.stringWidth(text))/2;
        int y=(clip.height-(ascent+descent))/2+ascent;
        //画上文字
        g2.drawString(text,x,y);
        //销毁g2d对象
        g2.dispose();
        //保存文件
        File f=new File(filename);
        if(!f.exists())f.createNewFile();
        ImageIO.write(image,"png",f);
        //返回returnName
        return returnName;
    }
}
