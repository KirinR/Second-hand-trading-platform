package com.luckyweimc.shctp.util;

import org.springframework.util.DigestUtils;

/**
 * 密码工具类
 */
public class PasswordUtil {

    //MD5前缀
    private static final String md5Key="GRM_SB";

    /**
     * 加密
     * @param password 密码
     * @return
     */
    public static String encode(String password){
        //添加前缀
        password=md5Key+password;
        //两次MD5加密
        return DigestUtils.md5DigestAsHex(DigestUtils.md5Digest(password.getBytes()));
    }
}
