package com.luckyweimc.shctp.util;

import javax.servlet.http.HttpServletRequest;

/**
 * servlet工具类
 */
public class ServletUtil {
    /**
     * 判断地址是否有效
     * @param addr IP地址
     * @return 是否有效
     */
    public static boolean isValidAddr(String addr){
        boolean valid=!(addr==null||addr.length()==0||addr.equalsIgnoreCase("unknown"));
        return valid;
    }

    /**
     * 获得客户端的IP地址
     * 一开始是拿来生成和校验验证码
     * 但是后来发现获得的IP地址可能是IPV4也可能是IPV6
     * 会造成验证码校验错误所以弃用了
     * @param request servlet请求
     * @return 客户端IP地址
     */
    public static final String getClientAddr(HttpServletRequest request){
        String addr;
        /**
         * 重重获取http请求头中可能保存的IP地址,如果都没有则返回request.getRemoteAddr()
         */
        addr=request.getHeader("x-forwarded-for");
        if(!isValidAddr(addr))addr=request.getHeader("Proxy-Client-IP");
        if(!isValidAddr(addr))addr=request.getHeader("WL-Proxy-Client-IP");
        if(!isValidAddr(addr))addr=request.getHeader("HTTP_CLIENT_IP");
        if(!isValidAddr(addr))addr=request.getHeader("HTTP_X_FORWARDED_FOR");
        if(!isValidAddr(addr))addr=request.getRemoteAddr();
        return addr;
    }

}
