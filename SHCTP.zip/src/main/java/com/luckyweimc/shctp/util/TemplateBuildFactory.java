package com.luckyweimc.shctp.util;

import com.luckyweimc.shctp.bean.User;
import org.springframework.web.servlet.ModelAndView;

/**
 * thymeleaf模板工厂
 */
public class TemplateBuildFactory {
    /**
     * 默认图标
     * 默认标题
     */
    private static final String DEFAULT_ICON="/res/image/icon.png";
    private static final String DEFAULT_TITLE="毛毛二手";

    //产生的视图ModelAndView
    private ModelAndView model;

    public TemplateBuildFactory() {
        model=new ModelAndView();
    }

    public TemplateBuildFactory(String model){
        this.model=new ModelAndView(model);
    }

    /**
     * 设置model名称
     * @param model
     * @return
     */
    public TemplateBuildFactory setModel(String model){
        this.model.setViewName(model);
        return this;
    }

    /**
     * 设置mapping
     * @param mapping
     * @return
     */
    public TemplateBuildFactory setMapping(String mapping){
        model.addObject("mapping",mapping);
        return this;
    }

    /**
     * 设置标题
     * @param title
     * @return
     */
    public TemplateBuildFactory setTitle(String title){
        model.addObject("title",title);
        return this;
    }

    /**
     * 设置图标
     * @param icon
     * @return
     */
    public TemplateBuildFactory setIcon(String icon){
        model.addObject("icon",icon);
        return this;
    }

    /**
     * 设置登录用户
     * @param loginUser
     * @return
     */

    public TemplateBuildFactory setLoginUser(User loginUser){
        if(loginUser!=null) {
            model.addObject("isLogin", true);
            model.addObject("loginUser", loginUser);
        }else{
            model.addObject("isLogin",false);
        }
        return this;
    }

    /**
     * 设置object
     * @param name
     * @param object
     * @return
     */
    public TemplateBuildFactory setObject(String name,Object object){
        model.addObject(name,object);
        return this;
    }

    /**
     * 创建ModelAndView
     * @return
     */
    public ModelAndView create(){
        return model;
    }

    /**
     * 创建默认BuildFactory
     * @param loginUser
     * @return
     */
    public static TemplateBuildFactory createBuildFactory(User loginUser){
        TemplateBuildFactory buildFactory=new TemplateBuildFactory("views");
        buildFactory.setIcon(DEFAULT_ICON);
        buildFactory.setTitle(DEFAULT_TITLE);
        buildFactory.setLoginUser(loginUser);
        return buildFactory;
    }

}
