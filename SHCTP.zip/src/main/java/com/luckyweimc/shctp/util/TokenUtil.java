package com.luckyweimc.shctp.util;

import org.springframework.util.DigestUtils;

import java.util.Random;

/**
 * Token工具类
 */
public class TokenUtil {
    /**
     * 字符表
     */
    private static final char table[]={
        '1','2','3','4','5','6','7','8','9','0',
        'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
        'A','B','C','D','E','F','G','H','I','J','L','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
        '~','!','@','#','$','%','^','&','*','(',')','-','+','{','}','|',':','"','<','>','?',
        '`',';','\\','\'',',','.','/'
    };

    /**
     * 生成指定长度的随机字符串
     * @param len 字符串长度
     * @param tableRange 字符表范围
     * @return
     */
    private static final String RandomString(Integer len,Integer tableRange){
        Random random=new Random();
        StringBuffer buffer=new StringBuffer();
        for(int i=0;i<len;i++){
            buffer.append(table[random.nextInt(tableRange)]);
        }
        return buffer.toString();
    }

    /**
     * 生成16长度的随机字符串然后拼接当前时间最后用MD5加密后返回作为Token
     * @return
     */
    public static final String genToken(){
        String rand=RandomString(16,table.length)+System.currentTimeMillis();
        return DigestUtils.md5DigestAsHex(rand.getBytes());
    }

    /**
     * 生成4长度的只由数字字母组成的验证码
     * @return
     */
    public static final String genVerify(){
        return RandomString(4,62);
    }
}
