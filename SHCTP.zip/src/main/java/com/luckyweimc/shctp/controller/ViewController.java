package com.luckyweimc.shctp.controller;

import com.luckyweimc.shctp.bean.*;
import com.luckyweimc.shctp.mapper.DeliverAddrMapper;
import com.luckyweimc.shctp.service.*;
import com.luckyweimc.shctp.util.ServletUtil;
import com.luckyweimc.shctp.util.TemplateBuildFactory;
import com.luckyweimc.shctp.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 此项目采用了前后端半分离的设计模式(用户操作作为api与前端分离,数据显示部分不分离)
 * 此Controller为数据视图Controller,通过thymeleaf将数据整合进模板中然后将视图返回给用户
 */
@RestController
public class ViewController {
    @Autowired
    CommodityService commodityService;
    @Autowired
    UserService userService;
    @Autowired
    VerifyService verifyService;
    @Autowired
    CommitService commitService;
    @Autowired
    OrderService orderService;
    @Autowired
    DeliverAddrMapper deliverAddrMapper;
    @GetMapping("/")
    public ModelAndView index(@RequestParam(name = "key",required = false)@Nullable String key, HttpServletRequest request){
        User loginUser=userService.isLogin(request);
        TemplateBuildFactory buildFactory=TemplateBuildFactory.createBuildFactory(loginUser).setMapping("index");
        String sessionId= TokenUtil.genToken();
        String loginVerifyImage=verifyService.genVerify(sessionId,1);
        String regVerifyImage=verifyService.genVerify(sessionId,0);
        buildFactory.setObject("sessionId",sessionId)
                .setObject("loginVerifyImage",loginVerifyImage)
                .setObject("regVerifyImage",regVerifyImage);
        if(key==null){
            buildFactory.setTitle("毛毛二手");
            key="";
        }else{
            buildFactory.setTitle(key+"的搜索结果");
        }
        List<Commodity> commodities=commodityService.getCommodityBySearch(key);
        Collections.sort(commodities, new Comparator<Commodity>() {
            @Override
            public int compare(Commodity o1, Commodity o2) {
                return o1.getSold()-o2.getSold();
            }
        });
        List<Commodity> foods=commodityService.getCommodityBySearch(key, CommodityType.Foods.getId());
        List<Commodity> toys=commodityService.getCommodityBySearch(key, CommodityType.Toys.getId());
        List<Commodity> books=commodityService.getCommodityBySearch(key, CommodityType.Books.getId());
        List<Commodity> clothes=commodityService.getCommodityBySearch(key, CommodityType.Clothes.getId());
        List<Commodity> electronics=commodityService.getCommodityBySearch(key, CommodityType.Electronics.getId());
        buildFactory.setObject("foods",foods)
                    .setObject("toys",toys)
                    .setObject("books",books)
                    .setObject("clothes",clothes)
                    .setObject("electronics",electronics)
                    .setObject("sortedCommodities",commodities);
        return buildFactory.create();
    }
    @GetMapping("/Commodity")
    public ModelAndView commodity(@RequestParam(name = "uid")@NonNull Long uid,HttpServletRequest request){
        User loginUser=userService.isLogin(request);
        TemplateBuildFactory buildFactory=TemplateBuildFactory.createBuildFactory(loginUser).setMapping("commodity");
        Commodity commodity=commodityService.getCommodityByUid(uid);
        String sessionId= TokenUtil.genToken();
        String loginVerifyImage=verifyService.genVerify(sessionId,1);
        String regVerifyImage=verifyService.genVerify(sessionId,0);
        buildFactory.setObject("sessionId",sessionId)
                    .setObject("loginVerifyImage",loginVerifyImage)
                    .setObject("regVerifyImage",regVerifyImage);
        if(commodity==null){
            buildFactory.setObject("noSuchCommodity",true).setObject("title","没有该商品");
            return buildFactory.create();
        }
        List<Commit> commits=commitService.getCommitByCommodity(uid);
        if(loginUser!=null&&loginUser.getUid()==commodity.getSeller().getUid()){
            buildFactory.setObject("CommodityOwner",true);
        }else if(loginUser!=null){
            buildFactory.setObject("deliverAddrs",deliverAddrMapper.getDeliverAddressByUser(loginUser.getUid()));
        }
        List<Order> biddings=orderService.getOrderByCommodity(commodity.getUid(),OrderStatus.Bidding.getId());
        Float maxPrince=orderService.getMaxPrinceByCommodity(uid);
        System.out.println(maxPrince);
        buildFactory.setObject("commodity",commodity)
                    .setObject("maxPrince",maxPrince)
                    .setObject("title",commodity.getName()+"-"+commodity.getSeller().getInformation().getNickname())
                    .setObject("commits",commits)
                    .setObject("biddings",biddings);
        return buildFactory.create();
    }
    @GetMapping("/Profile")
    public ModelAndView profile(@RequestParam(name = "uid",required = false)@Nullable Long uid,HttpServletRequest request){
        User loginUser=userService.isLogin(request);
        TemplateBuildFactory buildFactory=TemplateBuildFactory.createBuildFactory(loginUser).setMapping("profile");
        String sessionId= TokenUtil.genToken();
        String loginVerifyImage=verifyService.genVerify(sessionId,1);
        String regVerifyImage=verifyService.genVerify(sessionId,0);
        buildFactory.setObject("sessionId",sessionId)
                .setObject("loginVerifyImage",loginVerifyImage)
                .setObject("regVerifyImage",regVerifyImage);
        if(uid!=null){
            User user=userService.getUser(uid);
            if(user!=null) {
                buildFactory.setObject("otherUser", true)
                            .setObject("user", user)
                            .setObject("title",user.getInformation().getNickname()+"的资料");
            }
        }
        if(loginUser!=null){
            buildFactory.setObject("title","我的资料")
                    .setObject("deliverAddrs",deliverAddrMapper.getDeliverAddressByUser(loginUser.getUid()));
        }
        return buildFactory.create();
    }
    @GetMapping("/CustomCenter")
    public ModelAndView customCenter(HttpServletRequest request){
        User loginUser=userService.isLogin(request);
        TemplateBuildFactory buildFactory=TemplateBuildFactory.createBuildFactory(loginUser).setMapping("customCenter");
        String sessionId= TokenUtil.genToken();
        String loginVerifyImage=verifyService.genVerify(sessionId,1);
        String regVerifyImage=verifyService.genVerify(sessionId,0);
        buildFactory.setObject("sessionId",sessionId)
                .setObject("loginVerifyImage",loginVerifyImage)
                .setObject("regVerifyImage",regVerifyImage).setObject("title","用户中心");
        if(loginUser==null||loginUser.getType()!=UserType.Common){
            return buildFactory.setObject("permissionDenied",true).create();
        }
        List<Order> news=orderService.getCustomOrderByStatus(loginUser.getUid(),0);
        List<Order> biddings=orderService.getCustomOrderByStatus(loginUser.getUid(),1);
        List<Order> unPaids=orderService.getCustomOrderByStatus(loginUser.getUid(),2);
        List<Order> paids=orderService.getCustomOrderByStatus(loginUser.getUid(),3);
        List<Order> unDelivers=orderService.getCustomOrderByStatus(loginUser.getUid(),4);
        List<Order> delivereds=orderService.getCustomOrderByStatus(loginUser.getUid(),5);
        List<Order> completeds=orderService.getCustomOrderByStatus(loginUser.getUid(),6);
        List<Order> cancels=orderService.getCustomOrderByStatus(loginUser.getUid(),7);
        return buildFactory.setObject("news",news)
                    .setObject("biddings",biddings)
                    .setObject("unPaids",unPaids)
                    .setObject("paids",paids)
                    .setObject("unDelivers",unDelivers)
                    .setObject("delivereds",delivereds)
                    .setObject("completeds",completeds)
                    .setObject("cancels",cancels)
                    .create();
    }
    @GetMapping("/SellerCenter")
    public ModelAndView sellerCenter(HttpServletRequest request){
        User loginUser=userService.isLogin(request);
        TemplateBuildFactory buildFactory=TemplateBuildFactory.createBuildFactory(loginUser).setMapping("sellerCenter");
        String sessionId= TokenUtil.genToken();
        String loginVerifyImage=verifyService.genVerify(sessionId,1);
        String regVerifyImage=verifyService.genVerify(sessionId,0);
        buildFactory.setObject("sessionId",sessionId)
                .setObject("loginVerifyImage",loginVerifyImage)
                .setObject("regVerifyImage",regVerifyImage)
                .setObject("title","商家中心");
        if(loginUser==null||loginUser.getType()!=UserType.Seller){
            return buildFactory.setObject("permissionDenied",true).create();
        }
        List<Commodity> foods=commodityService.getCommodityBySeller(loginUser.getUid(), CommodityType.Foods.getId());
        List<Commodity> toys=commodityService.getCommodityBySeller(loginUser.getUid(), CommodityType.Toys.getId());
        List<Commodity> books=commodityService.getCommodityBySeller(loginUser.getUid(), CommodityType.Books.getId());
        List<Commodity> clothes=commodityService.getCommodityBySeller(loginUser.getUid(),  CommodityType.Clothes.getId());
        List<Commodity> electronics=commodityService.getCommodityBySeller(loginUser.getUid(), CommodityType.Electronics.getId());
        List<Order> news=orderService.getSellerOrderByStatus(loginUser.getUid(),0);
        List<Order> biddings=orderService.getSellerOrderByStatus(loginUser.getUid(),1);
        List<Order> unPaids=orderService.getSellerOrderByStatus(loginUser.getUid(),2);
        List<Order> paids=orderService.getSellerOrderByStatus(loginUser.getUid(),3);
        List<Order> unDelivers=orderService.getSellerOrderByStatus(loginUser.getUid(),4);
        List<Order> delivereds=orderService.getSellerOrderByStatus(loginUser.getUid(),5);
        List<Order> completeds=orderService.getSellerOrderByStatus(loginUser.getUid(),6);
        List<Order> cancels=orderService.getSellerOrderByStatus(loginUser.getUid(),7);
        return buildFactory.setObject("news",news)
                .setObject("biddings",biddings)
                .setObject("unPaids",unPaids)
                .setObject("paids",paids)
                .setObject("unDelivers",unDelivers)
                .setObject("delivereds",delivereds)
                .setObject("completeds",completeds)
                .setObject("cancels",cancels)
                .setObject("foods",foods)
                .setObject("toys",toys)
                .setObject("books",books)
                .setObject("clothes",clothes)
                .setObject("electronics",electronics)
                .create();
    }
    @GetMapping("/Order")
    public ModelAndView order(@RequestParam(name = "uid")@NonNull Long uid,HttpServletRequest request){
        User loginUser=userService.isLogin(request);
        TemplateBuildFactory buildFactory=TemplateBuildFactory.createBuildFactory(loginUser).setMapping("order");
        String sessionId= TokenUtil.genToken();
        String loginVerifyImage=verifyService.genVerify(sessionId,1);
        String regVerifyImage=verifyService.genVerify(sessionId,0);
        buildFactory.setObject("sessionId",sessionId)
                .setObject("loginVerifyImage",loginVerifyImage)
                .setObject("regVerifyImage",regVerifyImage);
        Order order=orderService.getOrderByUid(uid);
        if(order==null)return buildFactory.setObject("noSuchOrder",true).setObject("title","该订单不存在").create();
        if(loginUser==null)return buildFactory.setObject("title","请先登录").create();
        if(loginUser.getType()==UserType.Seller){
            if(order.getSeller().getUid()==loginUser.getUid()){
                if(order.getStatus()==OrderStatus.Paid)orderService.setStatus(order.getUid(),OrderStatus.UnDelivered.getId());
                return buildFactory.setObject("sellerOwner",true)
                        .setObject("title","订单:"+order.getUid())
                        .setObject("order",order).create();
            }
        }if(loginUser.getType()==UserType.Common){
            if(order.getCustom().getUid()==loginUser.getUid()){
                if(order.getStatus()==OrderStatus.New){
                    orderService.setStatus(order.getUid(),OrderStatus.Bidding.getId());
                    order.setStatus(OrderStatus.Bidding);
                }
                Float maxPrince=orderService.getMaxPrinceByCommodity(order.getCommodity().getUid());
                System.out.println(maxPrince);
                return buildFactory.setObject("customOwner",true)
                        .setObject("order",order)
                        .setObject("maxPrince",orderService.getMaxPrinceByCommodity(order.getCommodity().getUid()))
                        .setObject("title","订单:"+order.getUid())
                        .create();
            }
        }
        return buildFactory.setObject("title","这不是你的订单").create();
    }
}
