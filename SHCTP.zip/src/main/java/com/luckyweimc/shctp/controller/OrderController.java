package com.luckyweimc.shctp.controller;

import com.luckyweimc.shctp.APIStatus;
import com.luckyweimc.shctp.bean.*;
import com.luckyweimc.shctp.mapper.DeliverAddrMapper;
import com.luckyweimc.shctp.service.CommodityService;
import com.luckyweimc.shctp.service.OrderService;
import com.luckyweimc.shctp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
/**
 * 此项目采用了前后端半分离的设计模式(用户操作作为api与前端分离,数据显示部分不分离)
 * 此Controller为订单api Controller
 */
@RestController
public class OrderController {
    @Autowired
    OrderService orderService;
    @Autowired
    CommodityService commodityService;
    @Autowired
    UserService userService;
    @Autowired
    DeliverAddrMapper deliverAddrMapper;

    /**
     * 创建订单api
     * @param commodity 商品uid
     * @param amount 数量
     * @param deliveryAddrId 收货地址uid
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Order/Create")
    public APIStatus createOrder(@RequestParam(name = "commodity")@NonNull Long commodity,@RequestParam(name = "prince")@NonNull Float prince,@RequestParam(name = "amount")@NonNull Integer amount, @RequestParam(name = "deliverAddr")@NonNull Long deliveryAddrId,@RequestParam(name = "mode")@NonNull Integer mode, HttpServletRequest request){
        //校验是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null)return APIStatus.Error("您还未登录",null);
        //校验商品是否有效
        Commodity  c=commodityService.getCommodityByUid(commodity);
        if(c==null)return APIStatus.Error("该商品不存在",null);
        //校验数量是否在范围(0-c.getAmount()]内
        if(amount<=0||c.getAmount()<amount)return APIStatus.Error("数量超出范围",null);
        //校验收货地址是否有效
        DeliveryAddr deliveryAddr=deliverAddrMapper.getDeliverAddrByID(deliveryAddrId);
        if(deliveryAddr==null)return APIStatus.Error("地址无效",null);
        Float maxPrince=orderService.getMaxPrinceByCommodity(commodity);
        if(maxPrince==null)maxPrince=c.getPrince();
        if(prince<=maxPrince)return APIStatus.Error("出价过低",null);
        if(mode==1){
            if(prince!=3*c.getPrince())return APIStatus.Error("您给出的价格不符合一口价规则",null);
            Long order=orderService.addOrder(commodity,c.getSeller().getUid(),loginUser.getUid(),amount,deliveryAddrId,prince);
            orderService.setStatus(order,OrderStatus.Paid.getId());
        }
        //添加订单
        orderService.addOrder(commodity,c.getSeller().getUid(),loginUser.getUid(),amount,deliveryAddrId,prince);
        return APIStatus.Success("下单成功",null);
    }

    @PostMapping("/Api/Order/EndBidding")
    public APIStatus endBidding(@RequestParam(name = "commodity")@NonNull Long commodity,HttpServletRequest request){
        //校验是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null&&loginUser.getType()!=UserType.Seller)return APIStatus.Error("您不是商家或者您未登录",null);
        //校验商品是否有效且属于商家
        Commodity  c=commodityService.getCommodityByUid(commodity);
        if(c==null)return APIStatus.Error("该商品不存在",null);
        if(c.getSeller().getUid()!=loginUser.getUid())return APIStatus.Error("这不是你的商品",null);
        Order order=orderService.getMaxPrinceOrderByCommodity(commodity);
        if(order==null)return APIStatus.Error("还没有人竞价",null);
        orderService.setStatus(order.getUid(),OrderStatus.UnPaid.getId());
        orderService.removeBiddingOrdersByCommodity(c.getUid());
        return APIStatus.Success("终止竞拍成功",null);
    }
    /**
     * 取消订单api
     * @param uid 订单uid
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Order/Cancel")
    public APIStatus cancelOrder(@RequestParam(name = "uid")@NonNull Long uid,HttpServletRequest request){
        //校验是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null)return APIStatus.Error("您还未登录",null);
        //校验订单是否有效且是否属于登录用户,同时订单不能为完成状态
        Order order=orderService.getOrderByUid(uid);
        if(order==null)return APIStatus.Error("该订单不存在",null);
        if(order.getCustom().getUid()!=loginUser.getUid())return APIStatus.Error("这不是您的订单",null);
        if(order.getStatus()==OrderStatus.Completed)return APIStatus.Error("该订单已完成,无法取消",null);
        //更新订单状态
        orderService.setStatus(uid,OrderStatus.Canceled.getId());
        return APIStatus.Success("订单取消成功",null);
    }

    /**
     * 订单支付api(支付功能不好直接实现,故此处直接修改订单状态)
     * @param uid 订单uid
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Order/Pay")
    public APIStatus payOrder(@RequestParam(name = "uid")@NonNull Long uid,HttpServletRequest request){
        //校验是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null)return APIStatus.Error("您还未登录",null);
        //校验订单是否有效且是否属于登录用户,同时订单只能为UnPaid状态
        Order order=orderService.getOrderByUid(uid);
        if(order==null)return APIStatus.Error("该订单不存在",null);
        if(order.getCustom().getUid()!=loginUser.getUid())return APIStatus.Error("这不是您的订单",null);
        if(order.getStatus()!=OrderStatus.UnPaid)return APIStatus.Error("订单状态错误",null);
        //更新订单状态
        orderService.setStatus(uid,OrderStatus.Paid.getId());
        return APIStatus.Success("订单支付成功",null);
    }

    /**
     * 商家发货api
     * @param uid 订单api
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Order/Deliver")
    public APIStatus deliverOrder(@RequestParam(name = "uid")@NonNull Long uid,HttpServletRequest request){
        //校验是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null)return APIStatus.Error("您还未登录",null);
        //校验订单是否有效且是否属于登录用户,同时订单只能为已支付或未发货状态
        Order order=orderService.getOrderByUid(uid);
        if(order==null)return APIStatus.Error("该订单不存在",null);
        if(order.getSeller().getUid()!=loginUser.getUid())return APIStatus.Error("这不是您的订单",null);
        if(order.getStatus()!=OrderStatus.Paid&&order.getStatus()!=OrderStatus.UnDelivered)return APIStatus.Error("订单状态错误",null);
        //更新订单状态
        orderService.setStatus(uid,OrderStatus.Delivered.getId());
        return APIStatus.Success("发货成功",null);
    }

    @PostMapping("/Api/Order/UpdatePrince")
    public APIStatus updatePrince(@RequestParam(name = "uid")@NonNull Long uid,@RequestParam(name = "prince")@NonNull Float prince,HttpServletRequest request){
        //校验是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null)return APIStatus.Error("您还未登录",null);
        //校验订单是否有效且是否属于登录用户,同时订单只能为已支付或未发货状态
        Order order=orderService.getOrderByUid(uid);
        if(order==null)return APIStatus.Error("该订单不存在",null);
        if(order.getCustom().getUid()!=loginUser.getUid())return APIStatus.Error("这不是您的订单",null);
        if(order.getStatus()!=OrderStatus.Bidding)return APIStatus.Error("订单不处于竞价状态",null);
        Float maxPrince=orderService.getMaxPrinceByCommodity(order.getCommodity().getUid());
        if(prince<=maxPrince)return APIStatus.Error("出价过低",null);
        orderService.setPrince(uid,prince);
        return APIStatus.Success("出价成功",null);
    }

    /**
     * 确认收货api
     * @param uid 订单uid
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Order/Receive")
    public APIStatus receiveOrder(@RequestParam(name = "uid")@NonNull Long uid,HttpServletRequest request){
        //校验是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null)return APIStatus.Error("您还未登录",null);
        //校验订单是否有效且是否属于登录用户,同时订单只能为已发货状态
        Order order=orderService.getOrderByUid(uid);
        if(order==null)return APIStatus.Error("该订单不存在",null);
        if(order.getCustom().getUid()!=loginUser.getUid())return APIStatus.Error("这不是您的订单",null);
        if(order.getStatus()!=OrderStatus.Delivered)return APIStatus.Error("订单状态错误",null);
        //更新订单状态
        orderService.setStatus(uid,OrderStatus.Completed.getId());
        commodityService.addSold(order.getCommodity().getUid(),order.getAmount());
        return APIStatus.Success("收货成功",null);
    }

}
