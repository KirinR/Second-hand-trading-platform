package com.luckyweimc.shctp.controller;

import com.luckyweimc.shctp.APIStatus;
import com.luckyweimc.shctp.bean.*;
import com.luckyweimc.shctp.service.CommitService;
import com.luckyweimc.shctp.service.CommodityService;
import com.luckyweimc.shctp.service.OrderService;
import com.luckyweimc.shctp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
/**
 * 此项目采用了前后端半分离的设计模式(用户操作作为api与前端分离,数据显示部分不分离)
 * 此Controller为商品api Controller
 */
@RestController
public class CommodityController {
    @Autowired
    CommodityService commodityService;
    @Autowired
    UserService userService;
    @Autowired
    CommitService commitService;
    @Autowired
    OrderService orderService;

    /**
     * 上架商品api
     * @param name 商品名称
     * @param prince 商品价格
     * @param amount 商品数量
     * @param type 商品类型
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Commodity/Add")
    public APIStatus addCommodity(@RequestParam(name = "name")@NonNull String name, @RequestParam(name = "prince")@NonNull Float prince, @RequestParam(name = "amount")@NonNull Integer amount, @RequestParam(name = "type")@NonNull String type, HttpServletRequest request){
        //校验是否登录且是否为商家类型
        User loginUser=userService.isLogin(request);
        if(loginUser==null||loginUser.getType()!= UserType.Seller){
            return APIStatus.Error("权限不足,请先作为商家登录",null);
        }
        //商品数量不能为负数
        if(amount<0)return APIStatus.Error("商品数量不合法",null);
        Long seller=loginUser.getUid();
        //校验商品类型是否有效
        CommodityType commodityType=CommodityType.valueOf(type);
        if(commodityType==null)return APIStatus.Error("没有该商品类型",null);
        //添加商品
        Long uid=commodityService.addCommodity(seller,name,prince,amount,commodityType);
        return APIStatus.Success("商品编号:"+uid+"添加成功",null);
    }

    /**
     * 更新商品信息api
     * @param uid 商品uid
     * @param name 商品名称
     * @param prince 商品价格
     * @param amount 商品数量
     * @param type 商品类型
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Commodity/Update")
    public APIStatus updateCommodity(@RequestParam(name = "uid")@NonNull Long uid, @RequestParam(name = "name")@NonNull String name,@RequestParam(name = "prince")@NonNull Float prince,@RequestParam(name = "amount")@NonNull Integer amount,@RequestParam(name = "type")@NonNull String type,HttpServletRequest request){
        //校验是否登录且是否为商家类型
        User loginUser=userService.isLogin(request);
        if(loginUser==null||loginUser.getType()!= UserType.Seller){
            return APIStatus.Error("权限不足,请先作为商家登录",null);
        }
        //商品数量不能为负数
        if(amount<0)return APIStatus.Error("商品数量不合法",null);
        Long seller=loginUser.getUid();
        //校验商品是否有效且是否属于登录用户
        Commodity commodity=commodityService.getCommodityByUid(uid);
        if(commodity==null){
            return APIStatus.Error("该商品不存在",null);
        }
        if(commodity.getSeller().getUid()!=seller){
            return APIStatus.Error("这不是你的商品",null);
        }
        //校验商品类型是否有效
        CommodityType commodityType=CommodityType.valueOf(type);
        if(commodityType==null)return APIStatus.Error("没有该商品类型",null);
        //更新商品信息
        commodityService.setAmount(uid,amount);
        commodityService.setName(uid,name);
        commodityService.setPrince(uid,prince);
        commodityService.setType(uid,commodityType);
        return APIStatus.Success("商品编号:"+uid+"修改成功",null);
    }

    /**
     * 删除商品api
     * @param uid 商品uid
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Commodity/Remove")
    public APIStatus removeCommodity(@RequestParam(name = "uid")@NonNull Long uid,HttpServletRequest request){
        //校验是否登录且是否为商家类型
        User loginUser=userService.isLogin(request);
        if(loginUser==null||loginUser.getType()!= UserType.Seller){
            return APIStatus.Error("权限不足,请先作为商家登录",null);
        }
        //校验商品是否有效且是否属于登录用户
        Long seller=loginUser.getUid();
        Commodity commodity=commodityService.getCommodityByUid(uid);
        if(commodity==null){
            return APIStatus.Error("该商品不存在",null);
        }
        if(commodity.getSeller().getUid()!=seller){
            return APIStatus.Error("这不是你的商品",null);
        }
        //删除商品
        commodityService.removeCommodity(uid);
        return APIStatus.Success("删除成功",null);
    }

    /**
     * 上传商品预览图
     * @param uid 商品uid
     * @param file 预览图文件
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Commodity/Exhibition/Upload")
    public APIStatus uploadExhibition(@RequestParam(name = "uid")@NonNull Long uid, @RequestParam(name = "exhibition")@NonNull MultipartFile file,HttpServletRequest request){
        //校验是否登录且是否为商家类型
        User loginUser=userService.isLogin(request);
        if(loginUser==null||loginUser.getType()!= UserType.Seller){
            return APIStatus.Error("权限不足,请先作为商家登录",null);
        }
        //校验商品是否有效且是否属于登录用户
        Long seller=loginUser.getUid();
        Commodity commodity=commodityService.getCommodityByUid(uid);
        if(commodity==null){
            return APIStatus.Error("该商品不存在",null);
        }
        if(commodity.getSeller().getUid()!=seller){
            return APIStatus.Error("这不是你的商品",null);
        }
        //更新预览图
        Long id=commodityService.addExhibition(file,uid);
        if(id==-1L)return APIStatus.Error("上传失败",null);
        return APIStatus.Success("预览图上传成功",id);
    }

    /**
     * 删除预览图api
     * @param uid
     * @param commodityId
     * @param request
     * @return
     */
    @PostMapping("/Api/Commodity/Exhibition/Remove")
    public APIStatus removeExhibition(@RequestParam(name = "uid")@NonNull Long uid,@RequestParam(name = "commodity")@NonNull Long commodityId,HttpServletRequest request){
        User loginUser=userService.isLogin(request);
        if(loginUser==null||loginUser.getType()!= UserType.Seller){
            return APIStatus.Error("权限不足,请先作为商家登录",null);
        }
        Long seller=loginUser.getUid();
        Commodity commodity=commodityService.getCommodityByUid(commodityId);
        if(commodity==null){
            return APIStatus.Error("该商品不存在",null);
        }
        if(commodity.getSeller().getUid()!=seller){
            return APIStatus.Error("这不是你的商品",null);
        }
        commodityService.removeExhibition(uid);
        return APIStatus.Success("预览删除成功",null);
    }

    /**
     * 评论商品api
     * @param commodityId 商品uid
     * @param context 评论内容
     * @param commitType 评论类型(差评/中评/好评)
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/Commodity/Commit")
    public APIStatus commitCommidity(@RequestParam(name = "commodity")@NonNull Long commodityId,@RequestParam(name = "context")@NonNull String context,@RequestParam(name = "type")@NonNull String commitType,HttpServletRequest request){
        //校验是否作为顾客登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null||loginUser.getType()!= UserType.Common){
            return APIStatus.Error("权限不足,请先作为顾客登录",null);
        }
        //校验用户是否买过该商品
        List<Order> orders=orderService.getCustomOrderByStatus(loginUser.getUid(),OrderStatus.Completed.getId());
        boolean permit=false;
        for(Order o:orders){
            if(o.getCommodity().getUid()==commodityId)permit=true;
        }
        //没买过的用户没有评测权限
        if(!permit)return APIStatus.Error("您还没购买过该商品，没有评论权限",null);
        //校验商品是否有效
        Commodity commodity=commodityService.getCommodityByUid(commodityId);
        if(commodity==null){
            return APIStatus.Error("该商品不存在",null);
        }
        //校验评论类型是否有效
        CommitType type=CommitType.valueOf(commitType);
        if(type==null){
            return APIStatus.Error("没有该评论类型",null);
        }
        //提交评论
        commitService.addCommit(loginUser.getUid(),commodityId,context,type);
        return APIStatus.Success("评论成功",null);
    }
}
