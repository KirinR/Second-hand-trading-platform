package com.luckyweimc.shctp.controller;

import com.luckyweimc.shctp.APIStatus;
import com.luckyweimc.shctp.bean.*;
import com.luckyweimc.shctp.mapper.DeliverAddrMapper;
import com.luckyweimc.shctp.service.UserService;
import com.luckyweimc.shctp.service.VerifyService;
import com.luckyweimc.shctp.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * 此项目采用了前后端半分离的设计模式(用户操作作为api与前端分离,数据显示部分不分离)
 * 此Controller为用户api Controller
 */
@RestController
public class UserController {
    @Autowired
    UserService userService;
    @Autowired
    VerifyService verifyService;
    @Autowired
    DeliverAddrMapper deliverAddrMapper;

    /**
     * 用户登录api
     * @param session ViewController中的会话产生的session
     * @param uid   用户uid
     * @param password  密码
     * @param verify    验证码
     * @param request   servlet请求
     * @param response  servlet响应
     * @return API调用状态
     */
    @PostMapping("/Api/User/Login")
    public APIStatus login(@RequestParam(name = "session")@NonNull String session, @RequestParam(name = "uid")@NonNull Long uid, @RequestParam(name = "password")@NonNull String password, @RequestParam(name = "verify")@NonNull String verify, HttpServletRequest request, HttpServletResponse response){
        //校验验证码
        if(!verifyService.verify(session,verify,1))return APIStatus.Error("验证码校验失败",null);
        //登录,生成token
        UserToken token=userService.login(uid,password);
        //如果登录成功(token!=null)
        if(token!=null){
            //创建一个作用域为全站,名为loginToken,值为token的cookie
            Cookie cookie=new Cookie("loginToken",token.toString());
            cookie.setPath("/");
            //将cookie加入到servlet响应
            response.addCookie(cookie);
            //返回APIStatus
            return APIStatus.Success("登录成功",null);
        }
        //登录失败
        else{
            //返回APIStatus
            return APIStatus.Error("用户名或密码错误",null);
        }
    }

    /**
     * 用户注册api
     * @param session ViewController中的会话产生的session
     * @param nickname 用户昵称
     * @param password 用户密码
     * @param repeat 重复密码
     * @param verify 验证码
     * @param type 用户类型
     * @param request servlet请求
     * @param response servlet响应
     * @return API调用状态
     */
    @PostMapping("/Api/User/Register")
    public APIStatus register(@RequestParam(name = "session")@NonNull String session,@RequestParam(name = "nickname")@NonNull String nickname, @RequestParam(name = "password")@NonNull String password, @RequestParam(name = "repeat")@NonNull String repeat, @RequestParam("verify")@NonNull String verify, @RequestParam("type")@NonNull String type,HttpServletRequest request,HttpServletResponse response){
        //校验验证码
        if(!verifyService.verify(session,verify,0))return APIStatus.Error("验证码校验失败",null);
        //只允许注册顾客和商家类型
        if(!(type.equals("Seller")||type.equals("Common"))){
            return APIStatus.Error("注册类型错误",null);
        }
        //验证两次密码是否一致
        if(!password.equals(repeat)){
            return APIStatus.Error("两次密码不一致",null);
        }
        //注册用户
        Long uid=userService.register(password,nickname, UserType.valueOf(type));
        return APIStatus.Success("注册成功",uid);
    }

    /**
     * 用户登出api
     * @param response servlet响应
     * @return
     */
    @GetMapping("/Api/User/LoginOut")
    public APIStatus loginOut(HttpServletResponse response){
        //添加一个名为loginToken,有效期为0(即无效)的cookie覆盖原来的loginToken cookie实现注销
        Cookie cookie=new Cookie("loginToken","");
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);
        return APIStatus.Success("注销成功",null);
    }

    /**
     * 上传用户头像api
     * @param file 上传的头像文件
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/User/Avatar/Upload")
    public APIStatus updateAvatar(@RequestParam(name = "avatar")@NonNull MultipartFile file,HttpServletRequest request){
        //验证是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null){
            return APIStatus.Error("您还没有登录",null);
        }
        //更新头像
        if(userService.setAvatar(loginUser.getUid(),file))return APIStatus.Success("头像上传成功",null);
        else return APIStatus.Error("头像上传失败",null);
    }

    /**
     * 修改用户昵称api
     * @param nickname 要修改的昵称
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/User/Nickname/Update")
    public APIStatus updateNickname(@RequestParam(name = "nickname")@NonNull String nickname,HttpServletRequest request){
        //校验是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null){
            return APIStatus.Error("您还没有登录",null);
        }
        //设置昵称
        userService.setNickname(loginUser.getUid(),nickname);
        return APIStatus.Success("资料修改成功",null);
    }

    /**
     * 添加收货地址api
     * @param address 收货地址
     * @param phone 联系电话
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/User/DeliverAddress/Add")
    public APIStatus addDeliverAddress(@RequestParam(name = "address")@NonNull String address,@RequestParam(name = "phone")@NonNull String phone,HttpServletRequest request){
        //验证是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null){
            return APIStatus.Error("您还没有登录",null);
        }
        //获取新uid
        Long uid=deliverAddrMapper.getMaxUid();
        //校验phone是否合法(1开头的11位数字序列)
        System.out.println(phone);
        if((!phone.matches("^(1[0-9]*)$"))||phone.length()!=11)return APIStatus.Error("手机号码不合法",null);
        //添加收货地址
        deliverAddrMapper.addDeliverAddress(loginUser.getUid(),uid,address,phone);
        return APIStatus.Success("收货地址添加成功",uid);
    }

    /**
     * 更新收货地址api
     * @param uid deliverAddress的uid
     * @param address 收货地址
     * @param phone 联系电话
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/User/DeliverAddress/Update")
    public APIStatus updateDeliverAddress(@RequestParam(name = "uid")@NonNull Long uid, @RequestParam(name = "address")@NonNull String address,@RequestParam(name = "phone")@NonNull String phone,HttpServletRequest request){
        //验证是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null){
            return APIStatus.Error("您还没有登录",null);
        }
        System.out.println(phone);
        //校验phone是否合法(1开头的11位数字序列)
        if((!phone.matches("^(1[0-9]*)$"))||phone.length()!=11)return APIStatus.Error("手机号码不合法",null);
        //校验收货地址是否属于当前登录用户
        if(deliverAddrMapper.getDeliverAddrByID(uid).getUser()!=loginUser.getUid())return APIStatus.Error("这不是你的收货地址",null);
        //更新信息
        deliverAddrMapper.setAddress(address,uid);
        deliverAddrMapper.setPhone(address,uid);
        return APIStatus.Success("收货地址修改成功",uid);
    }

    /**
     * 删除收货地址api
     * @param uid 收货地址的uid
     * @param request servlet请求
     * @return
     */
    @PostMapping("/Api/User/DeliverAddress/Remove")
    public APIStatus removeDeliverAddress(@RequestParam(name = "uid")@NonNull Long uid,HttpServletRequest request){
        //验证是否登录
        User loginUser=userService.isLogin(request);
        if(loginUser==null){
            return APIStatus.Error("您还没有登录",null);
        }
        //验证收货地址是否有效,及是否属于登录用户
        DeliveryAddr deliveryAddr=deliverAddrMapper.getDeliverAddrByID(uid);
        if(deliveryAddr==null)return APIStatus.Error("该收货地址不存在",null);
        if(deliveryAddr.getUser()!=loginUser.getUid())return APIStatus.Error("这不是你的收货地址",null);
        //删除收货地址
        deliverAddrMapper.deleteAddress(uid);
        return APIStatus.Success("删除收货地址成功",uid);
    }

    /**
     * 刷新验证码api
     * @param type 验证码类型(登录(1)/注册(0))
     * @param session 上一次的session
     * @return
     */
    @GetMapping("/Api/RefreshVerify")
    public APIStatus refreshVerify(@RequestParam(name = "type")@NonNull Integer type,@RequestParam(name = "session")@NonNull String session){
        //清除上一个session的验证码
        verifyService.removeVerify(session,type);
        //生成新的session
        String sessionId= TokenUtil.genToken();
        //生成验证码,返回验证码图片
        String verifyImage=verifyService.genVerify(sessionId,type);
        //返回APIStatus,设置data为session和验证码图片路径
        return APIStatus.Success("刷新验证码成功",new VerifySession(sessionId,verifyImage));
    }
}
