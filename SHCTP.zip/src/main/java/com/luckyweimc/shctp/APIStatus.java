package com.luckyweimc.shctp;

/**
 * API状态类
 */
public class APIStatus {
    /**
     * 状态码 code
     * 调用信息 information
     * 携带数据data
     */
    private Integer code;
    private String information;
    private Object data;

    //成功码:100 失败码:200
    private static final Integer CODE_SUCCESS=100;
    private static final Integer CODE_ERROR=200;

    //全参构造器
    private APIStatus(Integer code, String information, Object data) {
        this.code = code;
        this.information = information;
        this.data = data;
    }

    //成功APIStatus
    public static final APIStatus Success(String information, Object data){
        return new APIStatus(CODE_SUCCESS,information,data);
    }

    //失败APIStatus
    public static final APIStatus Error(String information,Object data){
        return new APIStatus(CODE_ERROR,information,data);
    }

    //getters

    public Integer getCode() {
        return code;
    }

    public String getInformation() {
        return information;
    }

    public Object getData() {
        return data;
    }

}
