package com.luckyweimc.shctp.service;

import com.luckyweimc.shctp.bean.User;
import com.luckyweimc.shctp.bean.UserInfo;
import com.luckyweimc.shctp.bean.UserToken;
import com.luckyweimc.shctp.bean.UserType;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;

public interface UserService {

    User getUser(Long uid);

    User isLogin(HttpServletRequest request);

    UserToken login(Long uid,String password);

    Long register(String password,String nickname,UserType type);

    void setNickname(Long uid,String nickname);

    void setPassword(Long uid,String password);

    Boolean setAvatar(Long uid,MultipartFile file);
}
