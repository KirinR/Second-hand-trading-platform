package com.luckyweimc.shctp.service;

import com.luckyweimc.shctp.bean.*;
import com.luckyweimc.shctp.mapper.DeliverAddrMapper;
import com.luckyweimc.shctp.mapper.OrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderServiceImp implements OrderService{
    @Autowired
    OrderMapper mapper;
    @Autowired
    CommodityService commodityService;
    @Autowired
    UserService userService;
    @Autowired
    DeliverAddrMapper deliverAddrMapper;
    @Override
    public List<Order> getOrderByCommodity(Long commodity) {
        List<Order> result=new ArrayList<>();
        List<Long> uid=mapper.getUidByCommodity(commodity);
        for(Long i:uid){
            Order order=getOrderByUid(i);
            if(order!=null)result.add(getOrderByUid(i));
        }
        return result;
    }

    @Override
    public List<Order> getOrderByCommodity(Long commodity, Integer status) {
        List<Order> result=new ArrayList<>();
        List<Long> uid=mapper.getUidByCommodityAndStatus(commodity,status);
        for(Long i:uid){
            Order order=getOrderByUid(i);
            if(order!=null)result.add(getOrderByUid(i));
        }
        return result;
    }

    @Override
    public List<Order> getOrderBySeller(Long seller) {
        List<Order> result=new ArrayList<>();
        List<Long> uid=mapper.getUidBySeller(seller);
        for(Long i:uid){
            Order order=getOrderByUid(i);
            if(order!=null)result.add(getOrderByUid(i));
        }
        return result;
    }

    @Override
    public List<Order> getOrderByCustom(Long custom) {
        List<Order> result=new ArrayList<>();
        List<Long> uid=mapper.getUidByCustom(custom);
        for(Long i:uid){
            Order order=getOrderByUid(i);
            if(order!=null)result.add(getOrderByUid(i));
        }
        return result;
    }

    @Override
    public List<Order> getSellerOrderByStatus(Long seller, Integer status) {
        List<Order> result=new ArrayList<>();
        List<Long> uid=mapper.getUidBySellerAndStatus(seller,status);
        for(Long i:uid){
            Order order=getOrderByUid(i);
            if(order!=null)result.add(getOrderByUid(i));
        }
        return result;
    }

    @Override
    public List<Order> getCustomOrderByStatus(Long custom, Integer status) {
        List<Order> result=new ArrayList<>();
        List<Long> uid=mapper.getUidByCustomAndStatus(custom,status);
        for(Long i:uid){
            Order order=getOrderByUid(i);
            if(order!=null)result.add(getOrderByUid(i));
        }
        return result;
    }

    @Override
    public Order getOrderByUid(Long uid) {
        Integer amount=mapper.getAmount(uid);
        if(amount==null)return null;
        Long commodityId=mapper.getCommodityByUid(uid);
        if(commodityId==null)return null;
        Commodity commodity=commodityService.getCommodityByUid(commodityId);
        if(commodity==null)return null;
        Long customId=mapper.getCustomByUid(uid);
        if(customId==null)return null;
        User custom=userService.getUser(customId);
        if(custom==null)return null;
        Long sellerId=mapper.getSellerByUid(uid);
        if(sellerId==null)return null;
        User seller=userService.getUser(sellerId);
        if(seller==null)return null;
        Long deliverAddrId=mapper.getDeliveryAddrByUid(uid);
        if(deliverAddrId==null)return null;
        DeliveryAddr deliverAddr=deliverAddrMapper.getDeliverAddrByID(deliverAddrId);
        if(deliverAddr==null)return null;
        Integer statusId=mapper.getStatusByUid(uid);
        if(statusId==null)return null;
        OrderStatus status=OrderStatus.getStatus(statusId);
        if(status==null)return null;
        Date time=mapper.getTimeByUid(uid);
        if(time==null)return null;
        Float prince=mapper.getPrinceByUid(uid);
        if(prince==null)return null;
        return new Order(uid,commodity,seller,custom,deliverAddr,amount,status,time,prince);
    }

    @Override
    public Order getMaxPrinceOrderByCommodity(Long commodity) {
        Long order=mapper.getMaxPrinceUidByCommodity(commodity);
        if(order==null)return null;
        return getOrderByUid(order);
    }

    @Override
    public Float getMaxPrinceByCommodity(Long commodity) {
        return mapper.getMaxPrinceByCommodity(commodity);
    }

    @Override
    public void setStatus(Long uid, Integer status) {
        mapper.setStatus(uid,status);
    }

    @Override
    public void setDeliverAddr(Long uid, Long deliveraddr) {
        mapper.setDeliverAddr(uid,deliveraddr);
    }

    @Override
    public void setPrince(Long uid, Float prince) {
        mapper.setPrince(uid,prince);
    }

    @Override
    public void removeBiddingOrdersByCommodity(Long commodity) {
        mapper.removeOrdersByCommodityAndStatus(commodity,OrderStatus.New.getId());
        mapper.removeOrdersByCommodityAndStatus(commodity,OrderStatus.Bidding.getId());
    }

    @Override
    public Long addOrder(Long commodity, Long seller, Long custom, Integer amount, Long deliveraddr, Float prince) {
        Long uid=mapper.getMaxUid();
        mapper.addOrder(uid,commodity,seller,custom,amount,deliveraddr,OrderStatus.New.getId(),new Date(System.currentTimeMillis()),prince);
        return uid;
    }
}
