package com.luckyweimc.shctp.service;

import com.luckyweimc.shctp.bean.*;
import com.luckyweimc.shctp.mapper.CommitMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class CommitServiceImp implements CommitService {
    @Autowired
    CommitMapper mapper;
    @Autowired
    UserService userService;
    @Autowired
    CommodityService commodityService;
    @Override
    public void addCommit(Long user, Long commodity, String context, CommitType type) {
        Long uid=mapper.getMaxUid();
        mapper.addCommit(uid,commodity,user,context,type.getId(),new Date(System.currentTimeMillis()));
    }

    @Override
    public void removeCommit(Long uid) {
        mapper.deleteCommit(uid);
    }

    @Override
    public Commit getCommitByUid(Long uid) {
        Long userId=mapper.getUserByUid(uid);
        if(userId==null)return null;
        User user=userService.getUser(userId);
        if(user==null)return null;
        Long commodityId=mapper.getCommodityByUid(uid);
        if(commodityId==null)return null;
        Commodity commodity=commodityService.getCommodityByUid(commodityId);
        if(commodity==null)return null;
        String context=mapper.getContextByUid(uid);
        if(context==null)return null;
        Integer typeId=mapper.getTypeByUid(uid);
        if(typeId==null)return null;
        CommitType type=CommitType.getType(typeId);
        if(type==null)return null;
        Date time=mapper.getTimeByUid(uid);
        if(time==null)return null;
        return new Commit(uid,commodity,user,context,type,time);
    }

    @Override
    public List<Commit> getCommitByCommodity(Long commodity) {
        List<Commit> result=new ArrayList<>();
        List<Long> uid=mapper.getUidByCommodity(commodity);
        for(Long i:uid){
            Commit commit=getCommitByUid(i);
            if(commit!=null)result.add(commit);
        }
        return result;
    }

    @Override
    public List<Commit> getCommitByType(Long commodity, Integer type) {
        List<Commit> result=new ArrayList<>();
        List<Long> uid=mapper.getUidByType(commodity,type);
        for(Long i:uid){
            Commit commit=getCommitByUid(i);
            if(commit!=null)result.add(commit);
        }
        return result;
    }

    @Override
    public List<Commit> getCommitByUser(Long user) {
        List<Commit> result=new ArrayList<>();
        List<Long> uid=mapper.getUidByUser(user);
        for(Long i:uid){
            Commit commit=getCommitByUid(i);
            if(commit!=null)result.add(commit);
        }
        return result;
    }
}
