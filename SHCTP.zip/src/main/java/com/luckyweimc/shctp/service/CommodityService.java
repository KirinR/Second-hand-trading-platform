package com.luckyweimc.shctp.service;

import com.luckyweimc.shctp.bean.Commodity;
import com.luckyweimc.shctp.bean.CommodityType;
import com.luckyweimc.shctp.bean.Exhibition;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface CommodityService {

    Long addCommodity(Long seller, String name,Float prince,Integer amount, CommodityType type);

    Commodity getCommodityByUid(Long uid);

    void removeCommodity(Long uid);

    List<Commodity> getCommodityByType(Integer type);
    List<Commodity> getCommodityBySeller(Long seller);
    List<Commodity> getCommodityBySeller(Long seller,Integer type);
    List<Commodity> getCommodityBySearch(String key);
    List<Commodity> getCommodityBySearch(String key,Integer type);

    void setName(Long uid,String name);

    void setPrince(Long uid,Float prince);

    void setAmount(Long uid,Integer amount);

    void setType(Long uid,CommodityType type);

    void addSold(Long uid,Integer sold);

    Long addExhibition(MultipartFile res,Long commodity);

    void removeExhibition(Long exhibition);

    Exhibition getExhibitionByUid(Long exhibition);

    List<Exhibition> getExhibitionByCommodity(Long commodity);

}
