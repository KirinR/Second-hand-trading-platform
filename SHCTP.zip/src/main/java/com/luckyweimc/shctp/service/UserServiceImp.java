package com.luckyweimc.shctp.service;

import com.luckyweimc.shctp.bean.*;
import com.luckyweimc.shctp.mapper.DeliverAddrMapper;
import com.luckyweimc.shctp.mapper.UserInfoMapper;
import com.luckyweimc.shctp.mapper.UserMapper;
import com.luckyweimc.shctp.util.PasswordUtil;
import com.luckyweimc.shctp.util.TokenUtil;
import com.luckyweimc.shctp.util.UploadUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

@Service
public class UserServiceImp implements UserService {
    private static String AVATAR_SAVE_PATH;
    private static final String AVATAR_RES_PATH="/res/image/avatar/";
    private static final String DEFAULT_AVATAR="/res/image/avatar/default_avatar.png";
    private static final Long REGISTER_FORBID=-1L;
    private static final Long PASSWORD_TOO_SHORT=-2L;
    private static final Long PASSWORD_TOO_LONG=-3L;

    @Autowired
    UserMapper userMapper;
    @Autowired
    UserInfoMapper userInfoMapper;
    @Autowired
    DeliverAddrMapper deliverAddrMapper;

    @Override
    public User getUser(Long uid) {
        String password=userMapper.getPasswordByUid(uid);
        if(password==null)return null;
        Integer typeId=userMapper.getUserTypeByUid(uid);
        if(typeId==null)return null;
        UserType type=UserType.getType(typeId);
        if(type==null)return null;
        String nickname=userInfoMapper.getNicknameByUser(uid);
        if(nickname==null)return null;
        String avatar=userInfoMapper.getAvatarByUser(uid);
        if(avatar==null)return null;
        List<DeliveryAddr> address=deliverAddrMapper.getDeliverAddressByUser(uid);
        if(address==null)return null;
        return new User(uid,password,new UserInfo(nickname,avatar,address),type);
    }

    @Override
    public User isLogin(HttpServletRequest request) {
        Cookie cookies[]=request.getCookies();
        if(cookies==null)return null;
        for(Cookie c:cookies){
            if(c.getName().equals("loginToken")){
                UserToken token=UserToken.parse(c.getValue());
                if(token!=null&&userMapper.getTokenByUid(token.getUid()).equals(token.getToken())){
                    return getUser(token.getUid());
                }else {
                    return null;
                }
            }
        }
        return null;
    }

    @Override
    public UserToken login(Long uid, String password) {
        password=PasswordUtil.encode(password);
        String pass=userMapper.getPasswordByUid(uid);
        if(pass!=null&&pass.equals(password)){
            String token=TokenUtil.genToken();
            userMapper.setToken(uid,token);
            return new UserToken(uid,token);
        }
        return null;
    }

    @Override
    public Long register(String password,String nickname,UserType type) {
        if(password.length()<6)return PASSWORD_TOO_SHORT;
        if(password.length()>16)return PASSWORD_TOO_LONG;
        if(type!=UserType.Seller&&type!=UserType.Common)return REGISTER_FORBID;
        password=PasswordUtil.encode(password);
        Long uid=userMapper.getMaxUid();
        userMapper.registerUser(uid,password,type.getId());
        userInfoMapper.registerInfo(uid,nickname,DEFAULT_AVATAR);
        return uid;
    }

    @Override
    public void setNickname(Long uid, String nickname) {
        userInfoMapper.setNickname(uid,nickname);
    }

    @Override
    public void setPassword(Long uid, String password) {
        password=PasswordUtil.encode(password);
        userMapper.setPassword(uid,password);
    }

    @Override
    public Boolean setAvatar(Long uid, MultipartFile file) {
        try {
            AVATAR_SAVE_PATH = ResourceUtils.getURL("classpath:").getPath() + "static" + AVATAR_RES_PATH;
        }catch (IOException e){
            return false;
        }
        String avatar= UploadUtil.upload(file,AVATAR_SAVE_PATH,AVATAR_RES_PATH);
        if(avatar==null)return false;
        userInfoMapper.setAvatar(uid,avatar);
        return true;
    }

}
