package com.luckyweimc.shctp.service;

import com.luckyweimc.shctp.bean.Commit;
import com.luckyweimc.shctp.bean.CommitType;
import com.luckyweimc.shctp.bean.CommodityType;

import java.util.List;

/**
 * 评论服务
 */
public interface CommitService {
    /**
     * 添加评论
     * @param user 用户uid
     * @param commodity 商品uid
     * @param context 内容
     * @param type 评论类型
     */
    void addCommit(Long user, Long commodity, String context, CommitType type);

    /**
     * 删除评论
     * @param uid 评论uid
     */
    void removeCommit(Long uid);

    /**
     * 通过uid获取评论
     * @param uid 评论uid
     * @return
     */
    Commit getCommitByUid(Long uid);

    /**
     * 通过商品获得评论
     * @param commodity 商品uid
     * @return
     */
    List<Commit> getCommitByCommodity(Long commodity);

    /**
     * 通过获得某商品下某类型的评论
     * @param commodity 商品uid
     * @param type 评论类型id
     * @return
     */
    List<Commit> getCommitByType(Long commodity,Integer type);

    /**
     * 获得某用户的所有评论
     * @param user 用户uid
     * @return
     */
    List<Commit> getCommitByUser(Long user);
}
