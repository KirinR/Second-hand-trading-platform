package com.luckyweimc.shctp.service;

import com.luckyweimc.shctp.mapper.VerifyMapper;
import com.luckyweimc.shctp.util.ImageUtil;
import com.luckyweimc.shctp.util.PasswordUtil;
import com.luckyweimc.shctp.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;


import java.io.IOException;

@Service
public class VerifyServiceImp implements VerifyService {
    @Autowired
    VerifyMapper mapper;
    @Override
    public String genVerify(String address,Integer type) {
        mapper.removeVerify(address,type);
        String code=TokenUtil.genVerify();
        try {
            String LocalPath=ResourceUtils.getURL("classpath:").getPath()+"static";
            String returnName="/res/image/verify/"+ PasswordUtil.encode(code) +".png";
            String image= LocalPath+returnName;
            image=ImageUtil.genImageByText(30,image,returnName,code);
            mapper.insertVerify(address,code,type,image);
            return image;
        }catch (IOException e){
            e.printStackTrace();
            return "/res/image/verify/loadFailed.png";
        }
    }

    @Override
    public boolean verify(String address, String code, Integer type) {
        String v=mapper.getCodeByAddress(address,type);
        if(v==null||v.length()!=4)return false;
        boolean result=v.equalsIgnoreCase(code);
        if(result)mapper.removeVerify(address,type);
        return result;
    }

    @Override
    public void removeVerify(String address,Integer type) {
        mapper.removeVerify(address,type);
    }
}
