package com.luckyweimc.shctp.service;

import com.luckyweimc.shctp.bean.*;
import com.luckyweimc.shctp.mapper.CommodityMapper;
import com.luckyweimc.shctp.mapper.ExhibitionMapper;
import com.luckyweimc.shctp.util.UploadUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CommodityServiceImp implements CommodityService {
    private static String EXHIBITION_UPLOAD_PATH;
    private static final String EXHIBITION_RES_PATH="/res/image/exhibition/";
    @Autowired
    CommodityMapper mapper;
    @Autowired
    ExhibitionMapper exhibitionMapper;
    @Autowired
    UserService userService;

    @Override
    public Long addCommodity(Long seller, String name,Float prince, Integer amount, CommodityType type) {
        Long uid=mapper.getMaxUid();
        mapper.addCommodity(uid,seller,name,prince,amount,type.getId());
        return uid;
    }

    @Override
    public Commodity getCommodityByUid(Long uid) {
        Long sellerId=mapper.getSellerByUid(uid);
        if(sellerId==null)return null;
        User seller=userService.getUser(sellerId);
        if(seller==null)return null;
        String name=mapper.getNameByUid(uid);
        if(name==null)return null;
        Float prince=mapper.getPrinceByUid(uid);
        if(prince==null)return null;
        Integer amount=mapper.getAmountByUid(uid);
        if(amount==null)return null;
        Integer typeId=mapper.getTypeByUid(uid);
        if(typeId==null)return null;
        CommodityType type=CommodityType.getType(typeId);
        if(type==null)return null;
        List<Exhibition> exhibitions=getExhibitionByCommodity(uid);
        Integer sold=mapper.getSoldByUid(uid);
        if(sold==null)return null;
        Commodity commodity=new Commodity(uid,seller,name,prince,amount,type,exhibitions,sold);
        return commodity;
    }

    @Override
    public void removeCommodity(Long uid) {
        mapper.deleteCommodity(uid);
    }

    @Override
    public List<Commodity> getCommodityByType(Integer type) {
        List<Long> uid=mapper.getCommodityByType(type);
        List<Commodity> result=new ArrayList<>();
        for(Long i:uid){
            Commodity commodity=getCommodityByUid(i);
            if(commodity!=null)result.add(commodity);
        }
        return result;
    }



    @Override
    public List<Commodity> getCommodityBySeller(Long seller) {
        List<Long> uid=mapper.getCommodityBySeller(seller);
        List<Commodity> result=new ArrayList<>();
        for(Long i:uid){
            Commodity commodity=getCommodityByUid(i);
            if(commodity!=null)result.add(commodity);
        }
        return result;
    }

    @Override
    public List<Commodity> getCommodityBySeller(Long seller, Integer type) {
        List<Long> uid=mapper.getCommodityByType(type);
        List<Commodity> result=new ArrayList<>();
        for(Long i:uid){
            if(mapper.getSellerByUid(i)==seller) {
                Commodity commodity=getCommodityByUid(i);
                if(commodity!=null)result.add(commodity);
            }
        }
        return result;
    }

    @Override
    public List<Commodity> getCommodityBySearch(String key) {
        List<Long> uid=mapper.getAllCommodity();
        List<Commodity> result=new ArrayList<>();
        for(Long i:uid){
            if(mapper.getNameByUid(i).toUpperCase().contains(key.toUpperCase())) {
                Commodity commodity=getCommodityByUid(i);
                if(commodity!=null)result.add(commodity);
            }
        }
        return result;
    }

    @Override
    public List<Commodity> getCommodityBySearch(String key,Integer type) {
        List<Long> uid=mapper.getCommodityByType(type);
        List<Commodity> result=new ArrayList<>();
        for(Long i:uid){
            if(mapper.getNameByUid(i).toUpperCase().contains(key.toUpperCase())) {
                Commodity commodity=getCommodityByUid(i);
                if(commodity!=null)result.add(commodity);
            }
        }
        return result;
    }

    @Override
    public void setName(Long uid, String name) {
        mapper.setName(uid,name);
    }

    @Override
    public void setPrince(Long uid, Float prince) {
        mapper.setPrince(uid,prince);
    }

    @Override
    public void setAmount(Long uid, Integer amount) {
        mapper.setAmount(uid,amount);
    }

    @Override
    public void setType(Long uid, CommodityType type) {
        mapper.setType(uid,type.getId());
    }

    @Override
    public void addSold(Long uid, Integer sold) {
        Integer s=mapper.getSoldByUid(uid);
        s+=sold;
        Integer amount=mapper.getAmountByUid(uid);
        amount-=sold;
        mapper.setAmount(uid,amount);
        mapper.setSold(uid,s);
    }

    @Override
    public Long addExhibition(MultipartFile file, Long commodity) {
        try {
            EXHIBITION_UPLOAD_PATH = ResourceUtils.getURL("classpath:").getPath() + "static"+EXHIBITION_RES_PATH;
        }catch (IOException e){
            return -1L;
        }
        String res= UploadUtil.upload(file,EXHIBITION_UPLOAD_PATH,EXHIBITION_RES_PATH);
        if(res==null)return -1L;
        Long uid=exhibitionMapper.getMaxUid();
        exhibitionMapper.addExhibition(uid,commodity,res);
        return uid;
    }



    @Override
    public void removeExhibition(Long exhibition) {
        exhibitionMapper.deleteExhibition(exhibition);
    }

    @Override
    public Exhibition getExhibitionByUid(Long exhibition) {
        Long commodity=exhibitionMapper.getCommodityByUid(exhibition);
        String res=exhibitionMapper.getResByUid(exhibition);
        return new Exhibition(exhibition,commodity,res);
    }

    @Override
    public List<Exhibition> getExhibitionByCommodity(Long commodity) {
        List<Long> uid=exhibitionMapper.getUidByCommodity(commodity);
        List<Exhibition> result=new ArrayList<>();
        for(Long i:uid){
            result.add(getExhibitionByUid(i));
        }
        return result;
    }

}
