package com.luckyweimc.shctp.service;

/**
 * 验证码服务
 */
public interface VerifyService {
    /**
     * 生成验证码和验证码图片
     * @param address session(原为用户IP)
     * @param type 验证码类型 (登录验证码(1)/注册验证码(0))
     * @return 验证码图片路径
     */
    String genVerify(String address,Integer type);

    /**
     * 校验验证码
     * @param address session(原为用户IP)
     * @param code 验证码
     * @param type 验证码类型 (登录验证码(1)/注册验证码(0))
     * @return 校验是否通过
     */
    boolean verify(String address, String code, Integer type);

    /**
     * 删除验证码
     * @param address session(原为用户IP)
     * @param type 验证码类型 (登录验证码(1)/注册验证码(0))
     */
    void removeVerify(String address,Integer type);
}
