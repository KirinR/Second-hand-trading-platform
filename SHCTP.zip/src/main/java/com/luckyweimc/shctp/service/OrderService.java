package com.luckyweimc.shctp.service;

import com.luckyweimc.shctp.bean.Order;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.sql.Date;
import java.util.List;

public interface OrderService {

    List<Order> getOrderByCommodity(Long commodity);
    List<Order> getOrderByCommodity(Long commodity,Integer status);
    List<Order> getOrderBySeller(Long seller);
    List<Order> getOrderByCustom(Long custom);
    List<Order> getSellerOrderByStatus(Long seller,Integer status);
    List<Order> getCustomOrderByStatus(Long custom,Integer status);

    Order getOrderByUid(Long uid);

    Order getMaxPrinceOrderByCommodity(Long commodity);
    Float getMaxPrinceByCommodity(Long commodity);

    void setStatus(Long uid,Integer status);
    void setDeliverAddr(Long uid,Long deliveraddr);
    void setPrince(Long uid,Float prince);

    void removeBiddingOrdersByCommodity(Long commodity);

    Long addOrder(Long commodity,Long seller,Long custom,Integer amount,Long deliveraddr,Float prince);

}
