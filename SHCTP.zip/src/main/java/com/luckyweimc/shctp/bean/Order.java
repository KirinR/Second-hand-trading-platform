package com.luckyweimc.shctp.bean;

import java.sql.Date;

/**
 * 订单Bean
 */
public class Order {
    /**
     * uid
     * 商品commodity
     * 卖家seller
     * 顾客custom
     * 收货地址deliveryAddr
     * 数量amount
     * 状态status
     * 下单时间time
     * 出价prince
     */
    Long uid;
    Commodity commodity;
    User seller;
    User custom;
    DeliveryAddr deliveryAddr;
    Integer amount;
    OrderStatus status;
    Date time;
    Float prince;

    public Order(Long uid, Commodity commodity, User seller, User custom, DeliveryAddr deliveryAddr, Integer amount, OrderStatus status, Date time, Float prince) {
        this.uid = uid;
        this.commodity = commodity;
        this.seller = seller;
        this.custom = custom;
        this.deliveryAddr = deliveryAddr;
        this.amount = amount;
        this.status = status;
        this.time = time;
        this.prince = prince;
    }

    public Long getUid() {
        return uid;
    }

    public Commodity getCommodity() {
        return commodity;
    }

    public User getSeller() {
        return seller;
    }

    public User getCustom() {
        return custom;
    }

    public DeliveryAddr getDeliveryAddr() {
        return deliveryAddr;
    }

    public Integer getAmount() {
        return amount;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public Date getTime() {
        return time;
    }

    public Float getPrince() {
        return prince;
    }
    public void setStatus(OrderStatus status){
        this.status=status;
    }
}
