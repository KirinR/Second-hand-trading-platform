package com.luckyweimc.shctp.bean;

/**
 * 收货地址Bean
 */
public class DeliveryAddr {
    /**
     * uid
     * 用户user
     * 地址address
     * 联系电话phone
     */
    Long uid;
    Long user;
    String address;
    String phone;

    public DeliveryAddr(Long uid, Long user, String address, String phone) {
        this.uid = uid;
        this.user = user;
        this.address = address;
        this.phone = phone;
    }

    public Long getUid() {
        return uid;
    }

    public Long getUser() {
        return user;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }
}
