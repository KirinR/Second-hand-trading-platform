package com.luckyweimc.shctp.bean;

import java.util.List;

/**
 * 商品Bean
 */
public class Commodity {
    /**
     * uid
     * 卖家Seller
     * 名称name
     * 价格prince
     * 库存amount
     * 商品类型type
     * 预览图exhibitions
     * 销量sold
     */
    Long uid;
    User seller;
    String name;
    Float prince;
    Integer amount;
    CommodityType type;
    List<Exhibition> exhibitions;
    Integer sold;

    public Commodity(Long uid, User seller, String name, Float prince, Integer amount, CommodityType type, List<Exhibition> exhibitions, Integer sold) {
        this.uid = uid;
        this.seller = seller;
        this.name = name;
        this.prince = prince;
        this.amount = amount;
        this.type = type;
        this.exhibitions = exhibitions;
        this.sold = sold;
    }

    public Long getUid() {
        return uid;
    }

    public User getSeller() {
        return seller;
    }

    public String getName() {
        return name;
    }

    public Float getPrince() {
        return prince;
    }

    public Integer getAmount() {
        return amount;
    }

    public CommodityType getType() {
        return type;
    }

    public List<Exhibition> getExhibitions() {
        return exhibitions;
    }

    public Integer getSold() {
        return sold;
    }
}
