package com.luckyweimc.shctp.bean;

import java.util.List;

/**
 * 用户信息Bean
 */
public class UserInfo {
    /**
     * 昵称nickname
     * 头像avatar
     * 收货地址address
     */
    String nickname;
    String avatar;
    List<DeliveryAddr> address;

    public UserInfo(String nickname, String avatar, List<DeliveryAddr> address) {
        this.nickname = nickname;
        this.avatar = avatar;
        this.address = address;
    }

    public String getNickname() {
        return nickname;
    }

    public String getAvatar() {
        return avatar;
    }

    public List<DeliveryAddr> getAddress() {
        return address;
    }
}
