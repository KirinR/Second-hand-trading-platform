package com.luckyweimc.shctp.bean;

/**
 * 用户bean
 */
public class User {
    /**
     * uid
     * 密码password
     * 用户信息information
     * 用户类型type
     */
    Long uid;
    String password;
    UserInfo information;
    UserType type;

    public User(Long uid, String password, UserInfo information, UserType type) {
        this.uid = uid;
        this.password = password;
        this.information = information;
        this.type = type;
    }

    public Long getUid() {
        return uid;
    }

    public String getPassword() {
        return password;
    }

    public UserInfo getInformation() {
        return information;
    }

    public UserType getType() {
        return type;
    }
}
