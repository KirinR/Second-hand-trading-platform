package com.luckyweimc.shctp.bean;

/**
 * 用户类型枚举
 */
public enum  UserType {
    //管理员(0) 商家(1) 顾客(2)
    Admin(0),Seller(1),Common(2);

    Integer id;

    UserType(Integer id){
        this.id=id;
    }

    public Integer getId(){
        return id;
    }

    //根据id获得用户类型
    public static UserType getType(Integer id){
        switch (id){
            case 0:return Admin;
            case 1:return Seller;
            case 2:return Common;
        }
        return null;
    }

    public String toString() {
        switch (id){
            case 0:return "管理员";
            case 1:return "商家";
            case 2:return "顾客";
        }
        return "无效用户类型";
    }
}
