package com.luckyweimc.shctp.bean;

/**
 * 评论类型枚举类型
 */
public enum CommitType {
    //差评(0) 中评(1) 好评(2)
    Bad(0),Common(1),Good(2);

    Integer id;
    CommitType(Integer id){
        this.id=id;
    }

    public Integer getId(){
        return id;
    }

    //根据id返回评论类型
    public static CommitType getType(Integer id){
        switch (id){
            case 0:return Bad;
            case 1:return Common;
            case 2:return Good;
        }
        return Common;
    }

    @Override
    public String toString() {
        switch (id){
            case 0:return "差评";
            case 1:return "中评";
            case 2:return "好评";
        }
        return "无效评论类型";
    }
}
