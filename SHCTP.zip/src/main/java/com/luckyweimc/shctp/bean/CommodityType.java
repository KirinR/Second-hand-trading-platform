package com.luckyweimc.shctp.bean;

/**
 * 商品类型枚举类型
 */
public enum  CommodityType {
    //食品(0) 玩具(1) 书籍(2) 衣服(3) 电子产品(4)
    Foods(0),Toys(1),Books(2),Clothes(3),Electronics(4);

    Integer id;
    CommodityType(Integer id){
        this.id=id;
    }

    public Integer getId(){
        return id;
    }

    //根据id获得商品类型
    public static CommodityType getType(Integer id){
        switch (id){
            case 0:return Foods;
            case 1:return Toys;
            case 2:return Books;
            case 3:return Clothes;
            case 4:return Electronics;
        }
        return null;
    }

    //类型名称
    public String toString(){
        switch (id){
            case 0:return "食品";
            case 1:return "玩具";
            case 2:return "书籍";
            case 3:return "衣物";
            case 4:return "电子产品";
        }
        return "无效商品类型";
    }

}
