package com.luckyweimc.shctp.bean;

/**
 * 验证码Session集合体
 */
public class VerifySession {

    /**
     * session
     * 验证码图片image
     */

    String session;
    String image;

    public VerifySession(String session, String image) {
        this.session = session;
        this.image = image;
    }

    public String getSession() {
        return session;
    }

    public String getImage() {
        return image;
    }
}
