package com.luckyweimc.shctp.bean;

import java.sql.Date;

/**
 * 评论Bean
 */
public class Commit {

    /**
     * uid
     * 商品 commodity
     * 用户 user
     * 内容 context
     * 评论类型 type
     * 评论时间 time
     */
    Long uid;
    Commodity commodity;
    User user;
    String context;
    CommitType type;
    Date time;

    public Commit(Long uid, Commodity commodity, User user, String context, CommitType type, Date time) {
        this.uid = uid;
        this.commodity = commodity;
        this.user = user;
        this.context = context;
        this.type = type;
        this.time = time;
    }

    public Long getUid() {
        return uid;
    }

    public Commodity getCommodity() {
        return commodity;
    }

    public User getUser() {
        return user;
    }

    public String getContext() {
        return context;
    }

    public CommitType getType() {
        return type;
    }

    public Date getTime() {
        return time;
    }
}
