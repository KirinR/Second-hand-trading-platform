package com.luckyweimc.shctp.bean;

public enum OrderStatus {

    New(0),Bidding(1),UnPaid(2),Paid(3),UnDelivered(4),Delivered(5),Completed(6),Canceled(7);

    private Integer id;

    OrderStatus(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public static final OrderStatus getStatus(Integer id){
        switch (id){
            case 0:return New;
            case 1:return Bidding;
            case 2:return UnPaid;
            case 3:return Paid;
            case 4:return UnDelivered;
            case 5:return Delivered;
            case 6:return Completed;
            case 7:return Canceled;
            default:return null;
        }
    }
    public String toString(){
        switch (id){
            case 0:return "新订单";
            case 1:return "竞价中";
            case 2:return "未支付";
            case 3:return "已支付";
            case 4:return "未发货";
            case 5:return "已发货";
            case 6:return "已完成";
            case 7:return "已取消";
            default:return "无效订单类型";
        }
    }
}
