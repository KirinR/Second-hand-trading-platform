package com.luckyweimc.shctp.bean;

/**
 * 用于保存登录信息的UserToken
 */
public class UserToken {
    /**
     * 用户uid
     * token
     */
    Long uid;
    String token;

    public UserToken(Long uid, String token) {
        this.uid = uid;
        this.token = token;
    }

    public Long getUid() {
        return uid;
    }

    public String getToken() {
        return token;
    }

    //从cookie解析Token
    public static UserToken parse(String cookie){
        String split[]=cookie.split("&",2);
        if(split.length!=2)return null;
        return new UserToken(Long.valueOf(split[0]),split[1]);
    }
    //转为String用于保存在Cookie中
    @Override
    public String toString() {
        return uid.toString()+"&"+token;
    }
}
