package com.luckyweimc.shctp.bean;

/**
 * 商品预览图Bean
 */
public class Exhibition {
    /**
     * uid
     * 商品uid commodityId
     * 资源路径res
     */
    Long uid;
    Long commodityId;
    String res;

    public Exhibition(Long uid, Long commodityId, String res) {
        this.uid = uid;
        this.commodityId = commodityId;
        this.res = res;
    }

    public Long getUid() {
        return uid;
    }

    public Long getCommodityId() {
        return commodityId;
    }

    public String getRes() {
        return res;
    }
}
