package com.luckyweimc.shctp.mapper;

import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * 商品的数据库Mapper
 * 数据表
 * -------------------------------------------
 * uid |seller| name |prince|amount|type|sold
 * -------------------------------------------
 * long| long |string|float | int | int|int
 * -------------------------------------------
 */
@Mapper
public interface CommodityMapper {

    @Select("SELECT IFNULL(MAX(uid),-1)+1 FROM commodities")
    Long getMaxUid();

    @Select("SELECT uid FROM commodities")
    List<Long> getAllCommodity();
    @Select("SELECT uid FROM commodities WHERE type=#{type}")
    List<Long> getCommodityByType(Integer type);
    @Select("SELECT uid FROM commodities WHERE seller=#{seller}")
    List<Long> getCommodityBySeller(Long seller);

    @Select("SELECT type FROM commodities WHERE uid=#{uid}")
    Integer getTypeByUid(Long uid);
    @Select("SELECT name FROM commodities WHERE uid=#{uid}")
    String getNameByUid(Long uid);
    @Select("SELECT seller FROM commodities WHERE uid=#{uid}")
    Long getSellerByUid(Long uid);
    @Select("SELECT prince FROM commodities WHERE uid=#{uid}")
    Float getPrinceByUid(Long uid);
    @Select("SELECT amount FROM commodities WHERE uid=#{uid}")
    Integer getAmountByUid(Long uid);
    @Select("SELECT sold FROM commodities WHERE uid=#{uid}")
    Integer getSoldByUid(Long uid);

    @Update("UPDATE commodities SET amount=#{amount} WHERE uid=#{uid}")
    void setAmount(Long uid,Integer amount);
    @Update("UPDATE commodities SET name=#{name} WHERE uid=#{uid}")
    void setName(Long uid,String name);
    @Update("UPDATE commodities SET prince=#{prince} WHERE uid=#{uid}")
    void setPrince(Long uid,Float prince);
    @Update("UPDATE commodities SET type=#{type} WHERE uid=#{uid}")
    void setType(Long uid,Integer type);
    @Update("UPDATE commodities SET sold=#{sold} WHERE uid=#{uid}")
    void setSold(Long uid,Integer sold);

    @Insert("INSERT INTO commodities VALUES(#{uid},#{seller},#{name},#{prince},#{amount},#{type},0)")
    void addCommodity(Long uid,Long seller,String name,Float prince,Integer amount,Integer type);

    @Delete("DELETE FROM commodities WHERE uid=#{uid}")
    void deleteCommodity(Long uid);
}
