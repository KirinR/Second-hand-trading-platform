package com.luckyweimc.shctp.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * 用户信息的数据库Mapper
 * 数据表
 * ------------------------------------
 * user|nickname|avatar
 * ------------------------------------
 * long| string |string
 * ------------------------------------
 */

@Mapper
public interface UserInfoMapper {

    @Select("SELECT nickname FROM userinfos WHERE user=#{user}")
    String getNicknameByUser(Long user);

    @Select("SELECT avatar FROM userinfos WHERE user=#{user}")
    String getAvatarByUser(Long user);

    @Update("UPDATE userinfos SET nickname=#{nickname} WHERE user=#{user}")
    void setNickname(Long user,String nickname);

    @Update("UPDATE userinfos SET avatar=#{avatar} WHERE user=#{user}")
    void setAvatar(Long user,String avatar);

    @Insert("INSERT into userinfos VALUES(#{user},#{nickname},#{avatar})")
    void registerInfo(Long user,String nickname,String avatar);

}
