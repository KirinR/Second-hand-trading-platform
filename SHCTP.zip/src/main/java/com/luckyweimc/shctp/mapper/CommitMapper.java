package com.luckyweimc.shctp.mapper;

import org.apache.ibatis.annotations.*;

import java.sql.Date;
import java.util.List;

/**
 * 评论的数据库Mapper
 * 数据表
 * ------------------------------------
 * uid |commodity|user|context|type|time
 * ------------------------------------
 * long|  long  |long|string| int |date
 * ------------------------------------
 */
@Mapper
public interface CommitMapper {

    @Select("SELECT IFNULL(MAX(uid),-1)+1 FROM commits")
    Long getMaxUid();

    @Select("SELECT uid FROM commits WHERE commodity=#{commodity}")
    List<Long> getUidByCommodity(Long commodity);
    @Select("SELECT uid FROM commits WHERE user=#{user}")
    List<Long> getUidByUser(Long user);
    @Select("SELECT uid FROM commits WHERE commodity=#{commodity} AND type=#{type}")
    List<Long> getUidByType(Long commodity,Integer type);

    @Select("SELECT commodity FROM commits WHERE uid=#{uid}")
    Long getCommodityByUid(Long uid);
    @Select("SELECT user FROM commits WHERE uid=#{uid}")
    Long getUserByUid(Long uid);
    @Select("SELECT context FROM commits WHERE uid=#{uid}")
    String getContextByUid(Long uid);
    @Select("SELECT type FROM commits WHERE uid=#{uid}")
    Integer getTypeByUid(Long uid);
    @Select("SELECT time FROM commits WHERE uid=#{uid}")
    Date getTimeByUid(Long uid);


    @Insert("INSERT INTO commits VALUES(#{uid},#{commodity},#{user},#{context},#{type},#{time})")
    void addCommit(Long uid,Long commodity,Long user,String context,Integer type,Date time);

    @Delete("DELETE FROM commits WHERE uid=#{uid}")
    void deleteCommit(Long uid);

}
