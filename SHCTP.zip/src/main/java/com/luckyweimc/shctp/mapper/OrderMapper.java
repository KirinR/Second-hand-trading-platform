package com.luckyweimc.shctp.mapper;


import lombok.extern.flogger.Flogger;
import org.apache.ibatis.annotations.*;

import java.sql.Date;
import java.util.List;

/**
 * 预览图的数据库Mapper
 * 数据表
 * ------------------------------------------------------------
 * uid |commodity|seller|custom|deliveryaddr|amount|status|time
 * ------------------------------------------------------------
 * long|  long  | long | long |    long    |  int |  int  |date
 * ------------------------------------------------------------
 */

@Mapper
public interface OrderMapper {

    @Select("SELECT IFNULL(MAX(uid),-1)+1 FROM orders")
    Long getMaxUid();

    @Select("SELECT IFNULL(MAX(prince),0) FROM orders WHERE commodity=#{commodity} AND (status=1 OR status=0)")
    Float getMaxPrinceByCommodity(Long commodity);

    @Select("SELECT uid FROM orders WHERE commodity=#{commodity} AND (status=0 OR status=1) AND prince=(SELECT IFNULL(MAX(prince),0) FROM orders WHERE commodity=#{commodity} AND (status=1 OR status=0))")
    Long getMaxPrinceUidByCommodity(Long commodity);

    @Select("SELECT uid FROM orders WHERE commodity=#{commodity}")
    List<Long> getUidByCommodity(Long commodity);
    @Select("SELECT uid FROM orders WHERE seller=#{seller}")
    List<Long> getUidBySeller(Long seller);
    @Select("SELECT uid FROM orders WHERE custom=#{custom}")
    List<Long> getUidByCustom(Long custom);
    @Select("SELECT uid FROM orders WHERE seller=#{seller} AND status=#{status}")
    List<Long> getUidBySellerAndStatus(Long seller,Integer status);
    @Select("SELECT uid FROM orders WHERE custom=#{custom} AND status=#{status}")
    List<Long> getUidByCustomAndStatus(Long custom,Integer status);
    @Select("SELECT uid FROM orders WHERE commodity=#{commodity} AND status=#{status}")
    List<Long> getUidByCommodityAndStatus(Long commodity,Integer status);

    @Select("SELECT commodity FROM orders WHERE uid=#{uid}")
    Long getCommodityByUid(Long uid);
    @Select("SELECT seller FROM orders WHERE uid=#{uid}")
    Long getSellerByUid(Long uid);
    @Select("SELECT custom FROM orders WHERE uid=#{uid}")
    Long getCustomByUid(Long uid);
    @Select("SELECT amount FROM orders WHERE uid=#{uid}")
    Integer getAmount(Long uid);
    @Select("SELECT deliveryaddr FROM orders WHERE uid=#{uid}")
    Long getDeliveryAddrByUid(Long uid);
    @Select("SELECT time FROM orders WHERE uid=#{uid}")
    Date getTimeByUid(Long uid);
    @Select("SELECT status FROM orders WHERE uid=#{uid}")
    Integer getStatusByUid(Long uid);
    @Select("SELECT prince FROM orders WHERE uid=#{uid}")
    Float getPrinceByUid(Long uid);

    @Update("UPDATE orders SET status=#{status} WHERE uid=#{uid}")
    void setStatus(Long uid,Integer status);
    @Update("UPDATE orders SET deliveraddr=#{deliveraddr} WHERE uid=#{uid}")
    void setDeliverAddr(Long uid,Long deliveraddr);
    @Update("UPDATE orders SET prince=#{prince} WHERE uid=#{uid}")
    void setPrince(Long uid,Float prince);

    @Insert("INSERT INTO orders VALUES(#{uid},#{commodity},#{seller},#{custom},#{deliveraddr},#{amount},#{status},#{time},#{prince})")
    void addOrder(Long uid,Long commodity,Long seller,Long custom,Integer amount,Long deliveraddr,Integer status,Date time,Float prince);

    @Delete("DELETE FROM orders WHERE commodity=#{commodity} AND status=#{status}")
    void removeOrdersByCommodityAndStatus(Long commodity,Integer status);

}
