package com.luckyweimc.shctp.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
/**
 * 验证码的数据库Mapper
 * 原来是打算用用户IP作为验证码索引所以索引条目是address
 * 后来发现获取的用户IP有时是IPV6有时是IPV4,会产生冲突
 * 就改用请求的时候生成唯一session了,但条目名称就懒得改了
 * 数据表
 * ------------------------------------
 * address| code |type|image
 * ------------------------------------
 * string |string| int|string
 * ------------------------------------
 */
@Mapper
public interface VerifyMapper {
    @Insert("INSERT INTO verify VALUES(#{address},#{code},#{type},#{image})")
    void insertVerify(String address,String code,Integer type,String image);
    @Select("SELECT image FROM verify WHERE (address=#{address} AND type=#{type})")
    String getImageByAddress(String address,Integer type);
    @Select("SELECT code FROM verify WHERE (address=#{address} AND type=#{type})")
    String getCodeByAddress(String address,Integer type);
    @Delete("DELETE FROM verify WHERE (address=#{address} AND type=#{type})")
    void removeVerify(String address,Integer type);
}
