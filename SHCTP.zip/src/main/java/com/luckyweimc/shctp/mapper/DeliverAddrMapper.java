package com.luckyweimc.shctp.mapper;

import com.luckyweimc.shctp.bean.DeliveryAddr;
import org.apache.ibatis.annotations.*;

import java.util.List;
/**
 * 收货地址的数据库Mapper
 * 数据表
 * ------------------------------------
 * uid |user|address|phone
 * ------------------------------------
 * long|long| string|string
 * ------------------------------------
 */
@Mapper
public interface DeliverAddrMapper {

    @Select("SELECT IFNULL(MAX(uid),-1)+1 FROM deliveraddrs")
    Long getMaxUid();

    @Select("SELECT * FROM deliveraddrs WHERE user=#{user}")
    List<DeliveryAddr> getDeliverAddressByUser(Long user);
    @Select("SELECT * FROM deliveraddrs WHERE uid=#{uid}")
    DeliveryAddr getDeliverAddrByID(Long uid);

    @Insert("INSERT into deliveraddrs VALUES(#{uid},#{user},#{address},#{phone})")
    void addDeliverAddress(Long user,Long uid,String address,String phone);

    @Update("UPDATE deliveraddrs SET address=#{address} WHERE uid=#{uid}")
    void setAddress(String address,Long uid);
    @Update("UPDATE deliveraddrs SET phone=#{phone} WHERE uid=#{uid}")
    void setPhone(String  phone,Long uid);

    @Delete("DELETE FROM deliveraddrs WHERE uid=#{uid}")
    void deleteAddress(Long uid);
}
