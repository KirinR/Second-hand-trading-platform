package com.luckyweimc.shctp.mapper;

import org.apache.ibatis.annotations.*;
/**
 * 用户的数据库Mapper
 * 数据表
 * ------------------------------------
 * uid |password|type|token
 * ------------------------------------
 * long| string | int|string
 * ------------------------------------
 */
@Mapper
public interface UserMapper {
    @Select("SELECT IFNULL(MAX(uid),-1)+1 FROM users")
    Long getMaxUid();
    @Select("SELECT password FROM users WHERE uid=#{uid}")
    String getPasswordByUid(Long uid);
    @Select("SELECT token FROM users WHERE uid=#{uid}")
    String getTokenByUid(Long uid);
    @Select("SELECT type FROM users WHERE uid=#{uid}")
    Integer getUserTypeByUid(Long uid);
    @Insert("INSERT INTO users(uid,password,type) VALUES(#{uid},#{password},#{type})")
    Long registerUser(Long uid,String password,Integer type);
    @Update("UPDATE users SET password=#{password} WHERE uid=#{uid}")
    void setPassword(Long uid,String password);
    @Update("UPDATE users SET token=#{token} WHERE uid=#{uid}")
    void setToken(Long uid, String token);

}
