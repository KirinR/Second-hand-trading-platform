package com.luckyweimc.shctp.mapper;

import org.apache.ibatis.annotations.*;

import java.util.List;
/**
 * 预览图的数据库Mapper
 * 数据表
 * ------------------------------------
 * uid |commodity|res
 * ------------------------------------
 * long|  long  |string
 * ------------------------------------
 */
@Mapper
public interface ExhibitionMapper {

    @Select("SELECT IFNULL(MAX(uid),-1)+1 FROM exhibitions")
    Long getMaxUid();

    @Select("SELECT uid FROM exhibitions WHERE commodity=#{commodity}")
    List<Long> getUidByCommodity(Long commodity);
    @Select("SELECT commodity FROM exhibitions WHERE uid=#{uid}")
    Long getCommodityByUid(Long uid);
    @Select("SELECT res FROM exhibitions WHERE uid=#{uid}")
    String getResByUid(Long uid);

    @Insert("INSERT INTO exhibitions VALUES(#{uid},#{commodity},#{res})")
    void addExhibition(Long uid,Long commodity,String res);

    @Delete("DELETE FROM exhibitions WHERE uid=#{uid}")
    void deleteExhibition(Long uid);
}
