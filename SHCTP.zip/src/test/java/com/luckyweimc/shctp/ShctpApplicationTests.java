package com.luckyweimc.shctp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShctpApplicationTests {

    @Test
    void contextLoads() {
    }

}
